<?php

namespace App\Controllers;

use App\Models\doctorModel;

class Doctordetails extends BaseController
{
    public function index()
    {
        if (session()->get('user_id') == null) {
            return redirect()->to('login/index')->with('fail', 'You must be logged in..');
        }
        return view('doctordetails/index.php');
    }
    public function book($doctor_id){
        // session();
        // session()->regenerate();
        
        // $fname = session()->get('fname');
        // $status = '0';
        // $queryuser = $appointments->query("INSERT INTO appointments (fname, time, location) values('$fname','$time', $location)");
        // return redirect()->to('Search/index')->with('success', 'Pending approval by practitioner');
        // if (!$queryuser) {
        //  echo "fail";
       
   

        session();
        session()->regenerate();
        $fname = session()->get('fname');
        
        session();
        session()->regenerate();
        $patid = session()->get('user_id');

        $time = $this->request->getPost('time');

        $location = $this->request->getPost('location');  

        // $status = $this->request->getPost('status'); 
        $status = 'Confirmation Pending';   

        $appointment = new \App\Models\Appointments();
        $queryuser = $appointment->query("Insert into appointments (doctor_id, fname, time, location, status, patid) values('$doctor_id', '$fname', '$time', '$location', '$status', '$patid')");

        // $appdoc = new \App\Entities\appdoc($this->request->getPost());
        // $model=new \App\Models\AppointmentDoc();
        // $model->insert($appdoc);
        return redirect()->to('Doctordetails/index')->with('success', 'Sent for confirmation');
        // $queryuser = $appointments->query("INSERT INTO appointments (doctor_id) values('$doctor_id')");

     }
    // }
    public function doctorDetailsPage($id)
  {
        $appointments = new \App\Models\Appointments();

    session();
    

    session()->set('doctor_id', $id); 

    return view('doctordetails/index.php');
  }
}
