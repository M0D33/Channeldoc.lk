-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2022 at 05:46 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointmentdoc`
--

CREATE TABLE `appointmentdoc` (
  `doctor_id` text NOT NULL,
  `time` text NOT NULL,
  `location` text NOT NULL,
  `appointmentiddoc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointmentdoc`
--

INSERT INTO `appointmentdoc` (`doctor_id`, `time`, `location`, `appointmentiddoc`) VALUES
('9', '10-11am', 'Asiri', 1),
('4', '5-9pm', 'Hemas', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointmentdoc`
--
ALTER TABLE `appointmentdoc`
  ADD PRIMARY KEY (`appointmentiddoc`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointmentdoc`
--
ALTER TABLE `appointmentdoc`
  MODIFY `appointmentiddoc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
